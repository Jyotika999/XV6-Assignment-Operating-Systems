#ifndef PROC_INFO_H
#define PROC_INFO_H
struct processInfo
{
    int pid;
    int psize;
    int numberContextSwitches;
};
#endif
